#include <iostream>

using namespace std;

int main()
{
	cout.put('a');

	return 0;
}
