#pragma once

class Cherry
{
public:
	virtual void printType();
};
