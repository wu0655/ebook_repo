#pragma once

#include "Cherry.h"

class CherryTree
{
public:
	virtual Cherry* pick();
};
