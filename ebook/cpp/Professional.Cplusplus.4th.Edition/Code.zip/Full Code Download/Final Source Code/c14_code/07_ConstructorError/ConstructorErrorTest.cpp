#include "Matrix.h"
#include "Element.h"

int main()
{
	Matrix<Element> m(10, 10);
	return 0;
}
