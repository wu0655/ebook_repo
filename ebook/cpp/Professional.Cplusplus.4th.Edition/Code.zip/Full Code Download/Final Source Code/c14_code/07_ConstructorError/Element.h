#pragma once

class Element
{
	// Kept to a bare minimum, but in practice, this Element class
	// could throw exceptions in its constructor.
private:
	int mValue;
};
