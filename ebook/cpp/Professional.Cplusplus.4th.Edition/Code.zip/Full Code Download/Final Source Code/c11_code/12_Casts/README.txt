Compile each of the source files in this directory separately.

Note: 01_ConstCast.cpp will give a linker error.