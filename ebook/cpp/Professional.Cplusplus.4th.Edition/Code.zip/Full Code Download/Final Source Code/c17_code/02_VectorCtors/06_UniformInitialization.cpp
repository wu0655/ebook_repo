#include <vector>

using namespace std;

int main()
{
	vector<int> intVector1 = { 1, 2, 3, 4, 5, 6 };
	vector<int> intVector2{ 1, 2, 3, 4, 5, 6 };
	return 0;
}
