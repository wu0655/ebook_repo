#include <vector>

using namespace std;

class Element
{
public:
	Element() {}
	virtual ~Element() = default;
};

int main()
{
	vector<Element> elementVector;
	return 0;
}
