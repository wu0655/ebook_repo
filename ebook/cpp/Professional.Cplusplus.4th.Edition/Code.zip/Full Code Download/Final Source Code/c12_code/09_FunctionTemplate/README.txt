Include the following combinations of files in your project:

01_FindTemplate.cpp and SpreadsheetCell.cpp
or
02_FindTemplateSpecialization.cpp
or
03_FindTemplateOverload.cpp
or
04_FindTemplateSpecialOverload.cpp
