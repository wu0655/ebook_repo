#include "Grid.h"

#include <iostream>
using namespace std;

int main()
{
	Grid<> myIntGrid;
	Grid<int> myGrid;
	Grid<int, 5> anotherGrid;
	Grid<int, 5, 5> aFourthGrid;

	return 0;
}
