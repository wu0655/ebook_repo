module datamodel.address;

import <iostream>;

using namespace std;

DataModel::Address::Address()
{
	cout << "Address::Address()" << endl;
}
