import datamodel;

int main()
{
	DataModel::Person p;
	DataModel::Address a;
	DataModel::Persons persons;
}
