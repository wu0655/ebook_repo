#include <cstdio>

int main()
{
	printf("int %d\n", 5);
	printf("String %s and int %d\n", "hello", 5);
	printf("Many ints: %d, %d, %d, %d, %d\n", 1, 2, 3, 4, 5);
}
