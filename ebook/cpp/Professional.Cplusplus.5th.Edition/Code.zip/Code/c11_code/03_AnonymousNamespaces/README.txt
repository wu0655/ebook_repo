Compile AnotherFile.cpp and FirstFile.cpp together.


Notes:
	AnotherFile.cpp and FirstFile.cpp will fail at the link stage.
