Include the following combinations of files in your project:

01_FindTemplate.cpp and SpreadsheetCell.cpp and SpreadsheetCell.cppm
or
02_FindTemplateOverload.cpp
