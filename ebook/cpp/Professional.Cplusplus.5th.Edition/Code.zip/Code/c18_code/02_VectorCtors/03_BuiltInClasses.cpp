import <vector>;
import <string>;

using namespace std;

int main()
{
	vector<string> stringVector(10, "hello");
}
