import <vector>;

using namespace std;

int main()
{
	vector<int> intVector(10, 100); // creates a vector of 10 ints with value 100
}
