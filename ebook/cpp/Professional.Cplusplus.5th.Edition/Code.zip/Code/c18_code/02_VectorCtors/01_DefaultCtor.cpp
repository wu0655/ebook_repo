import <vector>;

using namespace std;

int main()
{
	vector<int> intVector; // creates a vector of ints with zero elements
}
