import <vector>;

using namespace std;

int main()
{
	vector<int> values;
	// Populate values ...
	vector<int>().swap(values);
}
