import <vector>;
import <string>;

using namespace std;

//void processVector(const vector<basic_string<char>>& vec)
//{
//	// Body omitted
//}

void processVector(const vector<string>& vec)
{
	// Body omitted
}

int main()
{
	//vector<basic_string<char>> myVector;
	vector<string> myVector;
	processVector(myVector);
	// Rest of the program ...
}
