import <iostream>;

using namespace std;

int main()
{
	int i{ 3 };
	cout << ((i > 2) ? "yes" : "no");
	cout << (i > 2 ? "yes" : "no");
}
