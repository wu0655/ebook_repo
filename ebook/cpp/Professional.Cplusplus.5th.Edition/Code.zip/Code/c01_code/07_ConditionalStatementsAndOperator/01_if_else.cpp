int main()
{
	int i{ 3 };

	if (i > 4) {
		// Do something.
	} else if (i > 2) {
		// Do something else.
	} else {
		// Do something else.
	}
}
