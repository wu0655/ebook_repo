module simulator;

import <iostream>;

using namespace Simulator;
using namespace std;

CarSimulator::CarSimulator()
{
	cout << "CarSimulator::CarSimulator()" << endl;
}
